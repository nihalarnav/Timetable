# timetable-generation-system
A timetable generation system using genetic algorithm created in JAVA.

## Overview
Timetable Generation System generates timetable for each class and teacher, in keeping with the availability calendar of teachers, availability and capacity of physical resources (such as classrooms, laboratories and computer room) and rules applicable at different classes, semesters, teachers and subjects level. Both GUI code and our algorithm were written in JAVA, which made the project platform independent. Genetic algorithm was used to optimize scheduling of time-table for each class.

## Tools/Libraries Used
Java 7, MS-Access, Eclipse IDE, Swing API
